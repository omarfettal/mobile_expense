package com.mmas.money_assistant_2608

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
